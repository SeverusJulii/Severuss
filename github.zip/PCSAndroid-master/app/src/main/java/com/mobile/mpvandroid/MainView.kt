package com.mobile.mpvandroid

interface MainView {
    //psg pjg
    fun updateTambah(luas: Float)
    fun showError (errorMsg: String)
}